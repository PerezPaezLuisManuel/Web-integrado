// Datos de ejemplo de productos
let products = [
    { id: 1, name: "Producto 1", price: 100 },
    { id: 2, name: "Producto 2", price: 150 },
    { id: 3, name: "Producto 3", price: 200 },
    { id: 4, name: "Producto 4", price: 120 },
    { id: 5, name: "Producto 5", price: 180 }
];

// Función para cargar los productos en la página
function loadProducts() {
    const productsContainer = document.getElementById('products');

    // Limpiar contenido anterior
    productsContainer.innerHTML = '';

    // Recorrer la lista de productos y crear elementos HTML
    products.forEach(product => {
        const productElement = createProductElement(product);
        productsContainer.appendChild(productElement);
    });

    // Botón para añadir productos
    const addProductButton = document.createElement('button');
    addProductButton.textContent = 'Añadir Producto';
    addProductButton.addEventListener('click', addProduct);
    productsContainer.appendChild(addProductButton);
}

// Función para crear un elemento de producto HTML
function createProductElement(product) {
    const productElement = document.createElement('div');
    productElement.classList.add('product');
    productElement.innerHTML = `
        <h3>${product.name}</h3>
        <p>Precio: $${product.price}</p>
        <button class="delete-btn" onclick="deleteProduct(${product.id})">Eliminar</button>
    `;
    return productElement;
}

// Función para añadir un nuevo producto
function addProduct() {
    const productName = prompt('Introduce el nombre del producto:');
    const productPrice = parseFloat(prompt('Introduce el precio del producto:'));

    if (productName && !isNaN(productPrice)) {
        const newProduct = {
            id: products.length + 1, // Generar un ID único (para ejemplo, no es persistente)
            name: productName,
            price: productPrice
        };
        products.push(newProduct);
        loadProducts(); // Recargar la lista de productos
    } else {
        alert('Por favor, introduce un nombre válido y precio numérico para el producto.');
    }
}

// Función para eliminar un producto por su ID
function deleteProduct(productId) {
    // Confirmar antes de eliminar (opcional)
    if (confirm(`¿Estás seguro de eliminar el producto con ID ${productId}?`)) {
        // Eliminar el producto de la lista
        products = products.filter(product => product.id !== productId);
        loadProducts(); // Recargar la lista de productos después de eliminar
    }
}

// Cargar los productos cuando la página esté lista
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
});
