Basic configuration for a Jakarta EE webapp.
