//importacion del paquete y librerias
package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

// Define el servlet con el nombre "GestionEmpleadosServlet" y el patrón de URL "/gestionEmpleados"
@WebServlet(name = "GestionEmpleadosServlet", urlPatterns = {"/gestionEmpleados"})
public class GestionEmpleadosServlet extends HttpServlet {
    
    // Lista de empleados que se gestionará en el servlet
    private ArrayList<String> empleados = new ArrayList<>();

    // Maneja las solicitudes GET
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Añade la lista de empleados como un atributo a la solicitud
        request.setAttribute("empleados", empleados);
        // Redirige la solicitud a "index.jsp", pasando los datos de la lista de empleados
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    // Maneja las solicitudes POST
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtiene el valor del parámetro "nombre" de la solicitud
        String nombreEmpleado = request.getParameter("nombre");
        // Añade el nuevo empleado a la lista
        empleados.add(nombreEmpleado);
        // Redirige al cliente a la URL "/gestionEmpleados" para actualizar la vista
        response.sendRedirect(request.getContextPath() + "/gestionEmpleados");
    }
}
