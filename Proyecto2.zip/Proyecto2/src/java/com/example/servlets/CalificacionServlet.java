package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

// Servlet para manejar la calificación de servicio
@WebServlet(name = "CalificacionServlet", urlPatterns = {"/calificar"})
public class CalificacionServlet extends HttpServlet {
    
    // Método POST para manejar las solicitudes POST
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtén los datos del formulario de la solicitud HTTP POST
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String serviceRating = request.getParameter("serviceRating");
        String serviceType = request.getParameter("serviceType");
        String comments = request.getParameter("comments");

        // Pasa los datos como atributos de la solicitud para enviarlos a la página de resultados
        request.setAttribute("name", name);
        request.setAttribute("email", email);
        request.setAttribute("serviceRating", serviceRating);
        request.setAttribute("serviceType", serviceType);
        request.setAttribute("comments", comments);

        // Redirige la solicitud a la página de resultados (result.jsp)
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }
}
